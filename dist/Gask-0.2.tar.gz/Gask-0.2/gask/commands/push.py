from gask.gittools.central_repo import update_to


def push():
    """Updating changes to a central repository"""
    update_to()
