from gask.gittools.central_repo import update_from


def pull():
    """Retrieving updates from a central repository"""
    update_from()
